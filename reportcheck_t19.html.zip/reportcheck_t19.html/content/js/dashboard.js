/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.84868421052632, "KoPercent": 1.1513157894736843};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.19457735247208932, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "http://159.89.38.11/login-9"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-8"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-5"], "isController": false}, {"data": [0.34210526315789475, 500, 1500, "http://159.89.38.11/login-4"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-7"], "isController": false}, {"data": [0.7631578947368421, 500, 1500, "http://159.89.38.11/login-6"], "isController": false}, {"data": [0.3157894736842105, 500, 1500, "http://159.89.38.11/login-1"], "isController": false}, {"data": [0.16666666666666666, 500, 1500, "http://159.89.38.11/login-0"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-19"], "isController": false}, {"data": [0.15789473684210525, 500, 1500, "http://159.89.38.11/login-3"], "isController": false}, {"data": [0.05263157894736842, 500, 1500, "http://159.89.38.11/login-2"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-16"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-15"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-18"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-17"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-12"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-11"], "isController": false}, {"data": [1.0, 500, 1500, "http://159.89.38.11/contact/manage"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-14"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-13"], "isController": false}, {"data": [0.9473684210526315, 500, 1500, "http://159.89.38.11/profile"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-10"], "isController": false}, {"data": [0.02631578947368421, 500, 1500, "http://159.89.38.11/login-21"], "isController": false}, {"data": [0.05263157894736842, 500, 1500, "http://159.89.38.11/login-20"], "isController": false}, {"data": [0.7894736842105263, 500, 1500, "http://159.89.38.11/"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 608, 7, 1.1513157894736843, 11636.715460526315, 26, 49874, 7304.0, 33744.8, 45448.299999999996, 48064.76, 4.778672032193159, 495.1218925491425, 6.893971556389116], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["http://159.89.38.11/login-9", 19, 2, 10.526315789473685, 25705.578947368424, 10572, 37128, 26131.0, 35047.0, 37128.0, 37128.0, 0.5105605417316064, 25.248132003412696, 0.8484762538963831], "isController": false}, {"data": ["http://159.89.38.11/login", 19, 2, 10.526315789473685, 47292.1052631579, 44331, 49874, 47428.0, 49863.0, 49874.0, 49874.0, 0.37544955143658854, 516.7616534477137, 7.354033180354108], "isController": false}, {"data": ["http://159.89.38.11/login-8", 19, 0, 0.0, 44196.52631578947, 33009, 48540, 45102.0, 47208.0, 48540.0, 48540.0, 0.38765225552404464, 197.10413643446637, 0.702520090333177], "isController": false}, {"data": ["http://159.89.38.11/login-5", 19, 0, 0.0, 15071.736842105265, 9694, 37960, 10681.0, 35787.0, 37960.0, 37960.0, 0.5002369543467958, 59.552211820730875, 0.20126721210046863], "isController": false}, {"data": ["http://159.89.38.11/login-4", 19, 0, 0.0, 2595.052631578947, 271, 17747, 898.0, 9686.0, 17747.0, 17747.0, 1.0158798053788163, 2.8273998489547134, 0.9428321158370315], "isController": false}, {"data": ["http://159.89.38.11/login-7", 19, 0, 0.0, 7264.473684210528, 3926, 14670, 6668.0, 11822.0, 14670.0, 14670.0, 1.1403192894010323, 26.609423294772537, 0.4632547113191694], "isController": false}, {"data": ["http://159.89.38.11/login-6", 19, 0, 0.0, 676.6315789473683, 26, 4907, 74.0, 2288.0, 4907.0, 4907.0, 3.3971035222599677, 53.5518728768103, 1.370120854192741], "isController": false}, {"data": ["http://159.89.38.11/login-1", 57, 1, 1.7543859649122806, 4277.771929824562, 270, 16459, 1678.0, 10919.400000000003, 13659.99999999999, 16459.0, 1.143889223359422, 8.43941667293799, 0.8424933837547662], "isController": false}, {"data": ["http://159.89.38.11/login-0", 57, 0, 0.0, 18684.070175438585, 561, 47936, 15760.0, 44781.6, 45690.899999999994, 47936.0, 1.1411182959300115, 204.3661772912454, 0.8215668542671818], "isController": false}, {"data": ["http://159.89.38.11/login-19", 19, 0, 0.0, 8313.578947368422, 3382, 22257, 6470.0, 16869.0, 22257.0, 22257.0, 0.8536640158152491, 41.42437982994114, 0.7714391820550838], "isController": false}, {"data": ["http://159.89.38.11/login-3", 19, 0, 0.0, 5770.421052631579, 1157, 21748, 2885.0, 15832.0, 21748.0, 21748.0, 0.8368569415081043, 13.527007906095841, 0.7546164772727273], "isController": false}, {"data": ["http://159.89.38.11/login-2", 38, 2, 5.2631578947368425, 6936.210526315789, 713, 18611, 5036.5, 15445.400000000001, 18419.1, 18611.0, 0.9964338158170757, 22.373513953351164, 0.6382891985263268], "isController": false}, {"data": ["http://159.89.38.11/login-16", 19, 0, 0.0, 9968.736842105263, 1856, 23396, 10944.0, 16077.0, 23396.0, 23396.0, 0.5707419645539201, 13.583547283343346, 0.5274728240462602], "isController": false}, {"data": ["http://159.89.38.11/login-15", 19, 0, 0.0, 12182.0, 1785, 25534, 14155.0, 22811.0, 25534.0, 25534.0, 0.5630630630630631, 10.204968151745495, 0.5247750062974158], "isController": false}, {"data": ["http://159.89.38.11/login-18", 19, 0, 0.0, 7068.8421052631575, 1697, 14488, 4976.0, 12749.0, 14488.0, 14488.0, 0.8434697682677795, 16.74172171879162, 0.7548135349152091], "isController": false}, {"data": ["http://159.89.38.11/login-17", 19, 0, 0.0, 12175.315789473683, 4831, 23746, 11003.0, 21709.0, 23746.0, 23746.0, 0.549514113836187, 45.30915591739935, 0.5035612220181629], "isController": false}, {"data": ["http://159.89.38.11/login-12", 19, 0, 0.0, 14931.526315789475, 5272, 30110, 14881.0, 24652.0, 30110.0, 30110.0, 0.5281445448227936, 22.776233495482973, 0.473663351285615], "isController": false}, {"data": ["http://159.89.38.11/login-11", 19, 0, 0.0, 16735.315789473683, 7832, 27117, 18159.0, 25734.0, 27117.0, 27117.0, 0.5621301775147929, 45.98083857248521, 0.5118285410502958], "isController": false}, {"data": ["http://159.89.38.11/contact/manage", 19, 0, 0.0, 327.36842105263156, 305, 386, 321.0, 366.0, 386.0, 386.0, 0.5955926146515784, 0.7258784991066111, 0.5283986493370114], "isController": false}, {"data": ["http://159.89.38.11/login-14", 19, 0, 0.0, 15211.421052631578, 7298, 29450, 12810.0, 27949.0, 29450.0, 29450.0, 0.4956952778502479, 38.19564472997652, 0.4590837382598487], "isController": false}, {"data": ["http://159.89.38.11/login-13", 19, 0, 0.0, 22842.631578947367, 9109, 37643, 23814.0, 33284.0, 37643.0, 37643.0, 0.4418810177217545, 65.25124079172288, 0.3984560328387367], "isController": false}, {"data": ["http://159.89.38.11/profile", 19, 0, 0.0, 347.8421052631579, 291, 741, 300.0, 563.0, 741.0, 741.0, 0.5182477769897986, 0.6312948352517593, 0.45650341293437346], "isController": false}, {"data": ["Test", 19, 2, 10.526315789473685, 48996.789473684206, 46067, 51610, 49185.0, 51516.0, 51610.0, 51610.0, 0.361959917701745, 499.95921997637737, 8.362565218271357], "isController": true}, {"data": ["http://159.89.38.11/login-10", 19, 0, 0.0, 13141.473684210527, 2256, 33134, 14712.0, 18420.0, 33134.0, 33134.0, 0.5351358963526264, 22.130273244965498, 0.48202387867905927], "isController": false}, {"data": ["http://159.89.38.11/login-21", 19, 0, 0.0, 3694.315789473684, 1093, 12420, 1842.0, 10684.0, 12420.0, 12420.0, 1.1125424522777843, 7.824737052055276, 0.9923448662021315], "isController": false}, {"data": ["http://159.89.38.11/login-20", 19, 0, 0.0, 3074.578947368421, 1233, 10926, 1851.0, 7557.0, 10926.0, 10926.0, 1.0237068965517242, 4.283773488011854, 0.9171058391702587], "isController": false}, {"data": ["http://159.89.38.11/", 38, 0, 0.0, 514.7368421052632, 304, 1287, 395.5, 777.1, 920.2999999999989, 1287.0, 0.8310915731688646, 1.0130210041991996, 0.726478946591431], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 3, 42.857142857142854, 0.4934210526315789], "isController": false}, {"data": ["Assertion failed", 4, 57.142857142857146, 0.6578947368421053], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 608, 7, "Assertion failed", 4, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 3, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["http://159.89.38.11/login-9", 19, 2, "Assertion failed", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/login", 19, 2, "Assertion failed", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/login-1", 57, 1, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/login-2", 38, 2, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
